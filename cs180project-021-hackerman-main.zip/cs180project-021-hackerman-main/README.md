# cs180project-021-hackerman
cs180project-021-hackerman created by GitHub Classroom      

This project is a data store that analyzes information about YouTube video data in different countries, and how each country's information compares with others (e.g. which videos are more popular between the United States and Japan).
